package com.uacf.chat.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uacf.chat.entity.Chat;
import com.uacf.chat.exception.ResourceNotFoundException;
import com.uacf.chat.repository.ChatRepository;
import com.uacf.chat.service.ChatService;

@RestController
@RequestMapping("/api")
public class ChatController {
	@Autowired
	private ChatService chatService;
	
	@Autowired
	ChatRepository chatRepository;
	

	//Get All chat
	@GetMapping("/chat")
	    public List<Chat> getAllNotes() {
	        return chatRepository.findAll();
	    }
	  
	//Get chat by ID
	@GetMapping("/chat/{id}")
	public Chat getChatByID(@PathVariable(value="id") Long chatId) {
		return chatRepository.findById(chatId)
				.orElseThrow(() -> new ResourceNotFoundException("Chat", "id", chatId));
		
	}
	


	//Get chat by Username
	@GetMapping("/chats/{username}")
	public Chat getChatByUsername(@PathVariable(value="username") String chatUsername) {
		return chatRepository.findByUsername(chatUsername)
				.orElseThrow(() -> new ResourceNotFoundException("Chat", "username", chatUsername));
		
	}
	
	
	//Create new chat
	@PostMapping("/chats")
	public Chat createChat(@Valid @RequestBody Chat chat) {
	    return chatRepository.save(chat);
	}
	

	  // READ--test
	@GetMapping("/chatsid/{id}")
	public List<String> getChat(@PathVariable(value="id") Long chatId)
	{
		Chat mychat=chatService.findOneID(chatId);
		System.out.println(mychat);
		List<String> chatUser= new ArrayList<String>();
		chatUser.add("username:" +mychat.getUsername());
		chatUser.add("text:" +mychat.getText());
		chatUser.add("text:" +mychat.getText());
		return chatUser;
		
		
	}

/*/	{
		Optional<Chat> chat1=chatService.findOne(chatId);		
		System.out.println("After Response:"+ResponseEntity.ok().body(chat1));
		if(chat1==null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(chat1);
	}*/
	
	//TEST
	@RequestMapping("/topics")
	public List<Chat> getAllTopics()
	{
		
		return chatService.getServiceAllTopics();
				
	}
	
}
