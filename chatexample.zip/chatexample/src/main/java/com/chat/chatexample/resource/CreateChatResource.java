package com.chat.chatexample.resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
public class CreateChatResource implements Serializable {
    private String username;
    private String text;
    private Integer timeout;
}
