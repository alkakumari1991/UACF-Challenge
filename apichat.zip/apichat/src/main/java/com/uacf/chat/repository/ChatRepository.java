package com.uacf.chat.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.uacf.chat.entity.Chat;

@Repository
public interface ChatRepository extends JpaRepository<Chat, Long>{

	Optional<Chat> findByUsername(String chatUsername);

	//Chat findOne(Long id);
	
	//@Query("select u.id,u.username from User u where u.id like %?1")
	  //List<Object[]> findByFirstnameEndsWith(String firstname);




}
