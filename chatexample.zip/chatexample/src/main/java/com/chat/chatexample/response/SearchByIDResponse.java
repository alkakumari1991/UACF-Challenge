package com.chat.chatexample.response;

import com.chat.chatexample.entity.Chat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SearchByIDResponse {
    private String username;
    private String text;
    private Date expiration_date;

    public static SearchByIDResponse createResponse(String userName, Chat chat) {
        return new SearchByIDResponse(userName, chat.getText(), new Date(chat.getExpiredOn()));
    }
}
