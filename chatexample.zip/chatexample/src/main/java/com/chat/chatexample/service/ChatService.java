package com.chat.chatexample.service;

import com.chat.chatexample.entity.Chat;
import com.chat.chatexample.entity.IdUser;
import com.chat.chatexample.entity.IdUserMap;
import com.chat.chatexample.entity.UserChat;
import com.chat.chatexample.resource.CreateChatResource;
import com.chat.chatexample.response.CreateResponse;
import com.chat.chatexample.response.SearchByIDResponse;
import com.chat.chatexample.response.SearchByUserNameResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.Calendar;

@Service
@Slf4j
public class ChatService {
    @Value("${store.directoryName}")
    private String directoryName;

    private static Long id = new Long("0");

    public CreateResponse create(CreateChatResource createChatResource) {
        String userName = createChatResource.getUsername();
        File file = getFile(userName);
        id = getId();
        if(file.exists()) {
            appendChat(file, id, createChatResource);
        } else {
            createChat(file, id, createChatResource);
        }
        mapIdToUser(id, createChatResource.getUsername());
        CreateResponse createResponse = new CreateResponse();
        createResponse.setId(id);
        return createResponse;
    }

    private void mapIdToUser(Long id, String username) {
        File file = new File(directoryName + File.separator  + "userid.json");
        if (file.exists()) {
            appendUserIdMap(id, username, file);
        } else {
            createUserIdMap(id, username, file);
        }
    }

    private void createUserIdMap(Long id, String username, File file) {
        try {
            file.createNewFile();
            IdUser idUser = new IdUser(id, username);
            ArrayList<IdUser> idUsers = new ArrayList<>();
            idUsers.add(idUser);
            IdUserMap idUserMap = new IdUserMap(idUsers);
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            writeToFile(file, ow.writeValueAsString(idUserMap));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void appendUserIdMap(Long id, String username, File file) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<IdUserMap> typeReference = new TypeReference<IdUserMap>(){};
            IdUserMap idUserMap = mapper.readValue(file, typeReference);
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            IdUser idUser = new IdUser(id, username);
            idUserMap.getIdUsers().add(idUser);;
            file.createNewFile();
            writeToFile(file, ow.writeValueAsString(idUserMap));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private Long getId() {
        System.out.println("Getting id");
        File file = new File(directoryName + File.separator  + "id.txt");
        if(id == 0) {
            if (file.exists()) {
                try {
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                    String st;
                    while ((st = bufferedReader.readLine()) != null) {
                        Long id = Long.parseLong(st) + 1;
                        writeIdToFile(file, id + "");
                        return id;
                    }
                } catch (IOException fnfe) {
                    fnfe.printStackTrace();
                }
            } else {
                writeIdToFile(file, "0");
            }
        } else {
            id ++;
            writeIdToFile(file, id+"");
        }
        return id;
    }

    private void writeIdToFile(File file, String id) {
        try {
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(id);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void appendChat(File file, Long id, CreateChatResource createChatResource) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<UserChat> typeReference = new TypeReference<UserChat>(){};
            UserChat userChat = mapper.readValue(file, typeReference);
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            Chat chat = new Chat(id, createChatResource.getText(), getExpiredTime(createChatResource.getTimeout()));
            userChat.getChats().add(chat);;
            file.createNewFile();
            writeToFile(file, ow.writeValueAsString(userChat));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private Long getExpiredTime(Integer timeout) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND, timeout);
        return calendar.getTime().getTime();
    }

    private void createChat(File file, Long id, CreateChatResource createChatResource) {
        try {
            file.createNewFile();
            Chat chat = new Chat(id, createChatResource.getText(), getExpiredTime(createChatResource.getTimeout()));
            ArrayList<Chat> chats = new ArrayList<>();
            chats.add(chat);
            UserChat userChat = new UserChat(chats);
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            writeToFile(file, ow.writeValueAsString(userChat));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void writeToFile(File file, String json) {
        try {
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(json);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private File getFile(String userName) {
        File file = new File(directoryName + File.separator + userName + ".json");
        return file;
    }

    public SearchByIDResponse searchByID(String id) {
        String userName = getUserNameForID(id);
        if(userName != null) {
            Chat chat = getChatByID(id, userName);
            return SearchByIDResponse.createResponse(userName, chat);
        }
        return null;
    }

    private Chat getChatByID(String id, String userName) {
        try {
            File file = getFile(userName);
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<UserChat> typeReference = new TypeReference<UserChat>(){};
            UserChat userChat = mapper.readValue(file, typeReference);
            ArrayList<Chat> chats = userChat.getChats();
            for (Chat chat : chats) {
                if(chat.getId() == Long.parseLong(id)) {
                    return chat;
                }
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return null;

    }

    private String getUserNameForID(String id) {
        try {
            File file = new File(directoryName + File.separator + "userid.json");
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<IdUserMap> typeReference = new TypeReference<IdUserMap>() {};
            IdUserMap idUserMap = mapper.readValue(file, typeReference);
            ArrayList<IdUser> idUsers = idUserMap.getIdUsers();
            for (IdUser idUser : idUsers) {
                if(idUser.getId() == Long.parseLong(id)) {
                    return idUser.getUsername();
                }
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return null;
    }

    public SearchByUserNameResponse searchByUserName(String userName) {
        try {
            ArrayList<Chat> filteredChats = new ArrayList<>();
            Long currentTime = getExpiredTime(0);
            File file = getFile(userName);
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<UserChat> typeReference = new TypeReference<UserChat>(){};
            UserChat userChat = mapper.readValue(file, typeReference);
            ArrayList<Chat> chats = userChat.getChats();
            for(Chat chat : chats) {
                if(currentTime <= chat.getExpiredOn()) {
                    filteredChats.add(chat);
                }
            }
            return SearchByUserNameResponse.createResponse(filteredChats);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return null;
    }
}
