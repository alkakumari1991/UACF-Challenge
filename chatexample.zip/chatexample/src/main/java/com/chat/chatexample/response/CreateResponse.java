package com.chat.chatexample.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateResponse {
    private Long id;
}
