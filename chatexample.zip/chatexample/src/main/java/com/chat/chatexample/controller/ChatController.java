package com.chat.chatexample.controller;

import com.chat.chatexample.resource.CreateChatResource;
import com.chat.chatexample.response.CreateResponse;
import com.chat.chatexample.response.SearchByIDResponse;
import com.chat.chatexample.response.SearchByUserNameResponse;
import com.chat.chatexample.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class ChatController {
    ChatService chatService;


    @Autowired
    public ChatController(ChatService chatService) {
        super();
        this.chatService = chatService;
    }

    @RequestMapping(value = "/chat", method = RequestMethod.POST)
    public @ResponseBody CreateResponse create(@RequestBody CreateChatResource createChatResource) {
        return chatService.create(createChatResource);
    }

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public ResponseEntity status() {
        System.out.println("UP!!!");
        return new ResponseEntity("UP", HttpStatus.CREATED);
    }

    @RequestMapping(value = "/chat/{id:.+}", method = RequestMethod.GET)
    private @ResponseBody SearchByIDResponse searchByID(@PathVariable String id) {
        return chatService.searchByID(id);
    }

    @RequestMapping(value = "/chats/{name:.+}", method = RequestMethod.GET)
    private ResponseEntity searchByUserName(@PathVariable String name) {
        return new ResponseEntity(chatService.searchByUserName(name).getChatResponses(), HttpStatus.OK);
    }
}
