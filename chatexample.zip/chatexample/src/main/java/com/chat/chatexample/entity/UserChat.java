package com.chat.chatexample.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
public class UserChat {
    private ArrayList<Chat> chats;
    public UserChat(ArrayList<Chat> chats) {
        this.chats = chats;
    }
}
