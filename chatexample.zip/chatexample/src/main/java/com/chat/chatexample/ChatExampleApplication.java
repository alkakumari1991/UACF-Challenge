package com.chat.chatexample;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.io.File;

@SpringBootApplication
@ComponentScan
public class ChatExampleApplication {

	@Value("${store.directoryName}")
	private String directoryName;

	public static void main(String[] args) {
		SpringApplication.run(ChatExampleApplication.class, args);
	}

	@Bean
	public boolean createDataFolder() {
		File directory = new File(String.valueOf(directoryName));
		if(!directory.exists()) {
			directory.mkdir();
		}
		return true;
	}
}
