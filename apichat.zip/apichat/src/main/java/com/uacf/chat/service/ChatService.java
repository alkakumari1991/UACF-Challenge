package com.uacf.chat.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uacf.chat.entity.Chat;
import com.uacf.chat.repository.ChatRepository;

@Service
public class ChatService {

	@Autowired 
	private ChatRepository chatRepository;
	
	private List<Chat> chats=new ArrayList<Chat>();
	
	public List<Chat> getServiceAllTopics(){
	return chatRepository.findAll();
	}
	
	
	public String getServiceChatById(long id) {
		System.out.println("ID is:"+id);
		System.out.println("CHAT is:"+chats);
		for(Chat chat:chats)
		{
			System.out.println("CHAT is :"+chat);
			Integer idChat=Integer.parseInt(chat.getId().toString());
			System.out.println("CHAT ID is :"+idChat);
			if(chat.getId().equals(id)) {
				//return topic;
				//chatRepository.findOne(chat.getId());
				System.out.println("Repo:"+chatRepository.getOne(id));

			            return chat.getId().toString()+ " : " + chat.getUsername().toString();

			    }
		}
		return null;
	}


	public Chat findOneID(Long chatId) {
		// TODO Auto-generated method stub
		return chatRepository.getOne(chatId);
	}

/*/
	public Optional<Chat> findOne(Long chatId) {
		//public S findOne(Long chatId) {
		System.out.println(chatRepository.findById(chatId));
		
		return chatRepository.findById(chatId);
		//return null;
	}
	*/

}
