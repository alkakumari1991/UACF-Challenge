package com.chat.chatexample.response;

import com.chat.chatexample.entity.Chat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SearchByUserNameResponse {
    private ArrayList<ChatResponse> chatResponses;

    public static SearchByUserNameResponse createResponse(ArrayList<Chat> chats) {
        ArrayList<ChatResponse> chatResponses = new ArrayList<>();
        for(Chat chat : chats) {
            chatResponses.add(new ChatResponse(chat.getId(), chat.getText()));
        }
        return new SearchByUserNameResponse(chatResponses);
    }
}
